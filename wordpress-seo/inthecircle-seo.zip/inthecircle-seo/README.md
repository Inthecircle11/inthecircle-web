# InTheCircle SEO Enhancements – WordPress Plugin

Implements all recommended SEO changes for inthecircle.co.

## What This Plugin Does

- **Meta tags:** Per-page title (50–60 chars) and description (150–160 chars)
- **Open Graph:** Facebook, LinkedIn sharing
- **Twitter Cards:** Twitter sharing
- **Canonical URLs:** Per-page canonicals
- **Schema.org JSON-LD:** Organization, WebSite, SoftwareApplication (site-wide)
- **FAQ Schema:** On FAQ page for rich results in Google
- **Internal links:** "Learn more about our mission" and "See our FAQ" on homepage
- **Image alt text:** Auto-adds alt text to logo/header images
- **Security headers:** X-Content-Type-Options, X-Frame-Options, Referrer-Policy, HSTS
- **Custom 404:** Branded "Page Not Found" with Back to Home / See FAQ links
- **Title override:** Stronger `document_title_parts` filter (priority 999) to beat theme/other plugins
- **All in One SEO override:** `aioseo_title`, `aioseo_description`, `aioseo_facebook_tags`, `aioseo_twitter_tags` – our values override AIOSEO
- **App Store URL (page builders):** JS fallback replaces placeholder in all links, including page builder blocks
- **GA4 conversion events:** Fires `sign_up` and `download_app` on click (mark as conversion in GA4)
- **Sticky header CTA:** Bar appears on scroll (300px+) with Sign Up Free and Download App buttons

## Installation

### Option 1: Upload as ZIP

1. Zip the `inthecircle-seo` folder (the folder containing `inthecircle-seo-enhancements.php` and `README.md`)
2. WordPress → Plugins → Add New → Upload Plugin → Choose the zip
3. Activate **InTheCircle SEO Enhancements**

### Option 2: FTP / File Manager

1. Upload the `wordpress-seo` folder to `wp-content/plugins/`
2. Rename it to `inthecircle-seo` (or keep as `wordpress-seo`)
3. WordPress → Plugins → Activate **InTheCircle SEO Enhancements**

## Page Slugs

The plugin maps these slugs to optimized titles/descriptions:

| Slug           | Title / Description |
|----------------|--------------------|
| (home)         | InTheCircle – #1 Networking App for Creators |
| about          | About InTheCircle – Creator Networking Platform |
| faq            | FAQ – InTheCircle Help Center |
| privacy-policy | Privacy Policy – InTheCircle |
| terms          | Terms of Service – InTheCircle |

If your page slugs differ, edit `itc_seo_get_page_data()` in the plugin file.

## Configuration

### App Store ID (no code editing)

1. Go to **Settings → InTheCircle SEO**
2. Enter your App Store ID (e.g. `6738291`)
3. Click Save

The plugin will replace the placeholder URL in all content. Leave as `123456789` until the app is published.

### OG Image (optional)

For best social sharing, use a 1200×630px image. Upload to Media Library and update `ITC_SEO_OG_IMAGE` in the plugin file if needed.

## Compatibility

- Works alongside Yoast SEO or Rank Math (this plugin runs first; you can disable their meta output if desired)
- No database changes
- Lightweight, no admin UI
