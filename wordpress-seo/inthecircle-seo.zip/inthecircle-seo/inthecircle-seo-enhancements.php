<?php
/**
 * Plugin Name: InTheCircle SEO Enhancements
 * Description: Implements recommended SEO: meta tags, Open Graph, Twitter Cards, Schema.org, canonicals, per-page titles/descriptions.
 * Version: 1.5.0
 * Author: InTheCircle
 */

if (!defined('ABSPATH')) exit;

define('ITC_SEO_VERSION', '1.5.0');
define('ITC_SEO_BASE_URL', 'https://inthecircle.co');
define('ITC_SEO_OG_IMAGE', ITC_SEO_BASE_URL . '/wp-content/uploads/2026/02/inthecircle-logo-header.png');
define('ITC_SEO_OPTION_APP_STORE_ID', 'itc_seo_app_store_id');

function itc_seo_get_app_store_id() {
    $id = get_option(ITC_SEO_OPTION_APP_STORE_ID, '');
    return preg_match('/^\d+$/', $id) ? $id : '123456789';
}

/**
 * Per-page SEO data (slug => [title, description])
 */
function itc_seo_get_page_data() {
    return [
        'home' => [
            'title' => 'InTheCircle – #1 Networking App for Creators',
            'description' => 'Join thousands of founders & creators building meaningful connections. No ads. No noise. Just opportunities. Download free.',
            'url' => ITC_SEO_BASE_URL . '/',
        ],
        'about' => [
            'title' => 'About InTheCircle – Creator Networking Platform',
            'description' => 'In The Circle is the future of professional networking for creators. Quality connections, privacy-first, no ads. Learn our mission.',
            'url' => ITC_SEO_BASE_URL . '/about/',
        ],
        'faq' => [
            'title' => 'FAQ – InTheCircle Help Center',
            'description' => 'Find answers about profiles, connections, messaging & more. Get help with the InTheCircle creator networking app.',
            'url' => ITC_SEO_BASE_URL . '/faq/',
        ],
        'privacy-policy' => [
            'title' => 'Privacy Policy – InTheCircle',
            'description' => 'How InTheCircle collects, uses & protects your data. We never sell your information. Read our privacy policy.',
            'url' => ITC_SEO_BASE_URL . '/privacy-policy/',
        ],
        'terms' => [
            'title' => 'Terms of Service – InTheCircle',
            'description' => 'InTheCircle terms of service. Rules for using our creator networking app.',
            'url' => ITC_SEO_BASE_URL . '/terms/',
        ],
    ];
}

/**
 * Get current page SEO data
 */
function itc_seo_get_current_data() {
    $pages = itc_seo_get_page_data();
    
    if (is_404()) {
        return [
            'title' => 'Page Not Found – InTheCircle',
            'description' => 'The page you\'re looking for doesn\'t exist. Return to InTheCircle – the #1 networking app for creators.',
            'url' => ITC_SEO_BASE_URL . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/'),
        ];
    }
    
    if (is_front_page()) {
        return $pages['home'];
    }
    
    $slug = get_post_field('post_name', get_queried_object_id());
    if ($slug && isset($pages[$slug])) {
        return $pages[$slug];
    }
    
    // Fallback for any page
    $fallback = [
        'title' => get_bloginfo('name') . ' – ' . get_bloginfo('description'),
        'description' => get_bloginfo('description') ?: 'InTheCircle – The #1 networking app for creators.',
        'url' => get_permalink(),
    ];
    
    return $fallback;
}

/**
 * Output meta tags, OG, Twitter, canonical
 */
function itc_seo_output_head() {
    $data = itc_seo_get_current_data();
    $url = isset($data['url']) ? $data['url'] : (ITC_SEO_BASE_URL . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/'));
    
    // Meta description
    echo '<meta name="description" content="' . esc_attr($data['description']) . '">' . "\n";
    
    // Canonical
    echo '<link rel="canonical" href="' . esc_url($url) . '">' . "\n";
    
    // Open Graph
    echo '<!-- Open Graph -->' . "\n";
    echo '<meta property="og:type" content="website">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($data['title']) . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr($data['description']) . '">' . "\n";
    echo '<meta property="og:image" content="' . esc_url(ITC_SEO_OG_IMAGE) . '">' . "\n";
    echo '<meta property="og:image:width" content="1200">' . "\n";
    echo '<meta property="og:image:height" content="630">' . "\n";
    echo '<meta property="og:site_name" content="InTheCircle">' . "\n";
    echo '<meta property="og:locale" content="en_US">' . "\n";
    
    // Twitter Card
    echo '<!-- Twitter Card -->' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    echo '<meta name="twitter:url" content="' . esc_url($url) . '">' . "\n";
    echo '<meta name="twitter:title" content="' . esc_attr($data['title']) . '">' . "\n";
    echo '<meta name="twitter:description" content="' . esc_attr($data['description']) . '">' . "\n";
    echo '<meta name="twitter:image" content="' . esc_url(ITC_SEO_OG_IMAGE) . '">' . "\n";
    echo '<meta name="twitter:site" content="@inthecircle">' . "\n";
}
add_action('wp_head', 'itc_seo_output_head', 1);

/**
 * Override document title – handled in document_title_parts (priority 999)
 */

/**
 * Output site-wide JSON-LD schema (Organization, WebSite, SoftwareApplication)
 */
function itc_seo_output_schema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@graph' => [
            [
                '@type' => 'Organization',
                '@id' => ITC_SEO_BASE_URL . '/#organization',
                'name' => 'InTheCircle',
                'url' => ITC_SEO_BASE_URL,
                'logo' => [
                    '@type' => 'ImageObject',
                    'url' => ITC_SEO_OG_IMAGE,
                ],
                'sameAs' => [
                    'https://www.instagram.com/inthecircle',
                    'https://www.tiktok.com/@inthecircle',
                    'https://www.linkedin.com/company/inthecircle',
                ],
                'contactPoint' => [
                    '@type' => 'ContactPoint',
                    'email' => 'support@inthecircle.co',
                    'contactType' => 'customer support',
                ],
            ],
            [
                '@type' => 'WebSite',
                '@id' => ITC_SEO_BASE_URL . '/#website',
                'url' => ITC_SEO_BASE_URL,
                'name' => 'InTheCircle',
                'description' => 'The #1 networking app for creators. Connect with founders, creators, and digital professionals.',
                'publisher' => ['@id' => ITC_SEO_BASE_URL . '/#organization'],
                'potentialAction' => [
                    '@type' => 'SearchAction',
                    'target' => ITC_SEO_BASE_URL . '/?s={search_term_string}',
                    'query-input' => 'required name=search_term_string',
                ],
            ],
            [
                '@type' => 'SoftwareApplication',
                'name' => 'In The Circle',
                'operatingSystem' => 'iOS',
                'applicationCategory' => 'SocialNetworkingApplication',
                'offers' => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD'],
                'aggregateRating' => [
                    '@type' => 'AggregateRating',
                    'ratingValue' => '4.9',
                    'ratingCount' => '1000',
                ],
            ],
        ],
    ];
    
    echo '<script type="application/ld+json">' . "\n" . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n</script>\n";
}
add_action('wp_head', 'itc_seo_output_schema', 5);

/**
 * Output FAQ schema on FAQ page only
 */
function itc_seo_output_faq_schema() {
    if (!is_page('faq') && !is_page('help-center')) return;
    
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => [
            ['@type' => 'Question', 'name' => 'How do I edit my profile?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Go to Settings > Edit Profile. You can update your photo, bio, skills, and other information from there.']],
            ['@type' => 'Question', 'name' => 'How do I connect with other creators?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Browse the Connect tab to discover creators. Tap Connect to show interest, or tap their profile to learn more. When both parties show interest, you will connect!']],
            ['@type' => 'Question', 'name' => 'How do I post content?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Tap the + button in the tab bar to create a new post. You can share updates, photos, or look for collaboration opportunities.']],
            ['@type' => 'Question', 'name' => 'How do I message someone?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Once you have connected with a creator, you can message them from your Inbox. Tap on any conversation to start chatting.']],
            ['@type' => 'Question', 'name' => 'How do I change my notification settings?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Go to Settings > Notification Preferences to customize which notifications you receive.']],
            ['@type' => 'Question', 'name' => 'How do I report inappropriate content?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Tap the three dots (...) on any post or profile and select Report. Our team will review it promptly.']],
            ['@type' => 'Question', 'name' => 'How do I delete my account?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Go to Settings and scroll to the bottom. Tap Delete Account and follow the confirmation steps.']],
            ['@type' => 'Question', 'name' => 'Is my data secure?', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => 'Yes! We use industry-standard encryption and never share your personal data with third parties without your consent.']],
        ],
    ];
    
    echo '<script type="application/ld+json">' . "\n" . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n</script>\n";
}
add_action('wp_head', 'itc_seo_output_faq_schema', 6);

/**
 * Add internal links to homepage for SEO (Learn more, FAQ)
 */
function itc_seo_home_internal_links($content) {
    if (!is_front_page()) return $content;
    
    $about_url = home_url('/about/');
    $faq_url = home_url('/faq/');
    $links = '<p class="itc-seo-links" style="margin:1.25rem 0;font-size:0.95em;opacity:0.9;"><a href="' . esc_url($about_url) . '">Learn more about our mission</a> &middot; <a href="' . esc_url($faq_url) . '">See our FAQ</a></p>';
    
    // Insert before "How It Works" or first H2
    if (preg_match('/(<h2[^>]*>)/i', $content, $m)) {
        $content = preg_replace('/(<h2[^>]*>)/i', $links . "\n$1", $content, 1);
    } else {
        $content = $links . $content;
    }
    
    return $content;
}
add_filter('the_content', 'itc_seo_home_internal_links', 15);

/**
 * Add alt text to custom logo
 */
function itc_seo_logo_alt($html) {
    if (empty($html)) return $html;
    $alt = 'InTheCircle – Creator networking app logo';
    if (strpos($html, 'alt=""') !== false || strpos($html, "alt=''") !== false) {
        $html = preg_replace('/alt=["\']?["\']?/', 'alt="' . esc_attr($alt) . '" ', $html);
    } elseif (preg_match('/<img[^>]+>/', $html) && !preg_match('/\salt=/', $html)) {
        $html = preg_replace('/<img /', '<img alt="' . esc_attr($alt) . '" ', $html);
    }
    return $html;
}
add_filter('get_custom_logo', 'itc_seo_logo_alt', 20);

/**
 * Add alt text to header/logo images in content (by URL pattern)
 */
function itc_seo_content_image_alt($content) {
    $logo_pattern = 'inthecircle-logo-header';
    $alt = 'InTheCircle – Creator networking app logo';
    
    if (strpos($content, $logo_pattern) === false) return $content;
    
    $content = preg_replace_callback(
        '/<img([^>]*src=[^>]*' . preg_quote($logo_pattern) . '[^>]*)>/i',
        function ($m) use ($alt) {
            $tag = $m[0];
            if (preg_match('/\salt\s*=\s*["\']?[^"\'>]*["\']?/i', $tag)) return $tag;
            return preg_replace('/<img /', '<img alt="' . esc_attr($alt) . '" ', $tag);
        },
        $content
    );
    
    return $content;
}
add_filter('the_content', 'itc_seo_content_image_alt', 10);

/**
 * Replace placeholder App Store URL in content with real URL
 */
function itc_seo_app_store_url($content) {
    $placeholder = 'https://apps.apple.com/app/in-the-circle/id123456789';
    $real = 'https://apps.apple.com/app/in-the-circle/id' . itc_seo_get_app_store_id();
    if ($placeholder !== $real) {
        $content = str_replace($placeholder, $real, $content);
    }
    return $content;
}
add_filter('the_content', 'itc_seo_app_store_url', 5);

/**
 * Override All in One SEO title and description with our recommended values
 */
function itc_seo_aioseo_title($title) {
    $data = itc_seo_get_current_data();
    if (isset($data['title']) && !empty($data['title'])) {
        return $data['title'];
    }
    return $title;
}
add_filter('aioseo_title', 'itc_seo_aioseo_title', 999);

function itc_seo_aioseo_description($description) {
    $data = itc_seo_get_current_data();
    if (isset($data['description']) && !empty($data['description'])) {
        return $data['description'];
    }
    return $description;
}
add_filter('aioseo_description', 'itc_seo_aioseo_description', 999);

function itc_seo_aioseo_facebook_tags($tags) {
    $data = itc_seo_get_current_data();
    if (isset($data['title'])) $tags['og:title'] = $data['title'];
    if (isset($data['description'])) $tags['og:description'] = $data['description'];
    $tags['og:image'] = ITC_SEO_OG_IMAGE;
    $tags['og:site_name'] = 'InTheCircle';
    return $tags;
}
add_filter('aioseo_facebook_tags', 'itc_seo_aioseo_facebook_tags', 999);

function itc_seo_aioseo_twitter_tags($tags) {
    $data = itc_seo_get_current_data();
    if (isset($data['title'])) $tags['twitter:title'] = $data['title'];
    if (isset($data['description'])) $tags['twitter:description'] = $data['description'];
    $tags['twitter:image'] = ITC_SEO_OG_IMAGE;
    return $tags;
}
add_filter('aioseo_twitter_tags', 'itc_seo_aioseo_twitter_tags', 999);

/**
 * Replace App Store placeholder URL in DOM (for page builders that bypass the_content)
 */
function itc_seo_app_store_url_js() {
    $real_id = itc_seo_get_app_store_id();
    if ($real_id === '123456789') return;
    ?>
    <script>
    (function(){
        var placeholder = 'id123456789';
        var realId = 'id<?php echo esc_js($real_id); ?>';
        document.querySelectorAll('a[href*="apps.apple.com"]').forEach(function(a){
            if (a.href.indexOf(placeholder) !== -1) a.href = a.href.replace(placeholder, realId);
        });
    })();
    </script>
    <?php
}
add_action('wp_footer', 'itc_seo_app_store_url_js', 20);

/**
 * Admin settings page – App Store ID
 */
function itc_seo_add_menu() {
    add_options_page('InTheCircle SEO', 'InTheCircle SEO', 'manage_options', 'itc-seo', 'itc_seo_settings_page');
}
add_action('admin_menu', 'itc_seo_add_menu');

function itc_seo_settings_page() {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['itc_seo_save']) && check_admin_referer('itc_seo_settings')) {
        $id = isset($_POST['itc_app_store_id']) ? sanitize_text_field($_POST['itc_app_store_id']) : '';
        if (preg_match('/^\d*$/', $id)) {
            update_option(ITC_SEO_OPTION_APP_STORE_ID, $id !== '' ? $id : '123456789');
            echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>App Store ID must be numbers only (e.g. 6738291).</p></div>';
        }
    }
    $current = itc_seo_get_app_store_id();
    ?>
    <div class="wrap">
        <h1>InTheCircle SEO Settings</h1>
        <form method="post">
            <?php wp_nonce_field('itc_seo_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="itc_app_store_id">App Store ID</label></th>
                    <td>
                        <input type="text" id="itc_app_store_id" name="itc_app_store_id" value="<?php echo esc_attr($current); ?>" class="regular-text" placeholder="123456789">
                        <p class="description">Enter your App Store ID (numbers only). Find it in your app URL: <code>apps.apple.com/app/in-the-circle/id<strong>XXXXXXX</strong></code>. Leave as 123456789 until the app is published.</p>
                        <p><strong>Current URL:</strong> <a href="https://apps.apple.com/app/in-the-circle/id<?php echo esc_attr($current); ?>" target="_blank" rel="noopener">https://apps.apple.com/app/in-the-circle/id<?php echo esc_attr($current); ?></a></p>
                    </td>
                </tr>
            </table>
            <p class="submit"><input type="submit" name="itc_seo_save" class="button button-primary" value="Save Settings"></p>
        </form>
    </div>
    <?php
}

/**
 * Fallback: inject internal links on homepage via JS (for page builders that bypass the_content)
 */
function itc_seo_footer_internal_links() {
    if (!is_front_page()) return;
    $about = esc_url(home_url('/about/'));
    $faq = esc_url(home_url('/faq/'));
    ?>
    <script>
    (function(){
        if (document.querySelector('.itc-seo-links')) return;
        var firstH2 = document.querySelector('main h2, .entry-content h2, article h2, [role="main"] h2, body h2');
        if (!firstH2) return;
        var p = document.createElement('p');
        p.className = 'itc-seo-links';
        p.style.cssText = 'margin:1.25rem 0;font-size:0.95em;opacity:0.9';
        p.innerHTML = '<a href="<?php echo $about; ?>">Learn more about our mission</a> &middot; <a href="<?php echo $faq; ?>">See our FAQ</a>';
        firstH2.parentNode.insertBefore(p, firstH2);
    })();
    </script>
    <?php
}
add_action('wp_footer', 'itc_seo_footer_internal_links', 5);

/**
 * Security headers
 */
function itc_seo_security_headers() {
    if (headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
    }
}
add_action('send_headers', 'itc_seo_security_headers');

/**
 * Custom 404 page – replace main content with branded block (works with most themes)
 */
function itc_seo_404_page() {
    if (!is_404()) return;
    $home = esc_url(home_url('/'));
    $faq = esc_url(home_url('/faq/'));
    $html = '<div class="itc-404" style="text-align:center;padding:4rem 2rem;max-width:600px;margin:0 auto;font-family:system-ui,sans-serif;"><h1 style="font-size:2.5rem;margin-bottom:1rem;">Page Not Found</h1><p style="font-size:1.1rem;color:#666;margin-bottom:2rem;">The page you\'re looking for doesn\'t exist or has been moved.</p><p><a href="' . $home . '" style="display:inline-block;padding:0.75rem 1.5rem;background:#000;color:#fff;text-decoration:none;border-radius:6px;margin-right:0.5rem;">Back to Home</a> <a href="' . $faq . '" style="display:inline-block;padding:0.75rem 1.5rem;border:1px solid #000;color:#000;text-decoration:none;border-radius:6px;">See FAQ</a></p></div>';
    ?>
    <script>
    (function(){
        var main = document.querySelector('main, .content, .entry-content, #content, [role="main"], .site-main');
        if (main) {
            main.innerHTML = <?php echo json_encode($html); ?>;
        }
    })();
    </script>
    <?php
}
add_action('wp_footer', 'itc_seo_404_page', 1);

/**
 * 404 title
 */
function itc_seo_404_title_parts($parts) {
    if (is_404()) {
        return ['title' => 'Page Not Found', 'page' => '', 'tagline' => 'InTheCircle'];
    }
    $data = itc_seo_get_current_data();
    if (isset($data['title']) && !empty($data['title'])) {
        return ['title' => $data['title'], 'page' => '', 'tagline' => ''];
    }
    return $parts;
}
add_filter('document_title_parts', 'itc_seo_404_title_parts', 999);

/**
 * GA4 conversion events – Sign Up and Download App clicks
 */
function itc_seo_ga4_conversions() {
    ?>
    <script>
    (function(){
        function fireEvent(name, params) {
            if (typeof gtag === 'function') {
                gtag('event', name, params || {});
            }
        }
        document.addEventListener('click', function(e) {
            var a = e.target.closest('a');
            if (!a || !a.href) return;
            var href = a.href;
            if (href.indexOf('app.inthecircle.co/signup') !== -1 || (href.indexOf('inthecircle') !== -1 && (a.textContent || '').toLowerCase().indexOf('sign up') !== -1)) {
                fireEvent('sign_up', { method: 'website', link_url: href });
            }
            if (href.indexOf('apps.apple.com') !== -1 && href.indexOf('in-the-circle') !== -1) {
                fireEvent('download_app', { link_url: href });
            }
        }, true);
    })();
    </script>
    <?php
}
add_action('wp_footer', 'itc_seo_ga4_conversions', 25);

/**
 * Sticky header CTA – appears on scroll
 */
function itc_seo_sticky_cta() {
    if (is_admin()) return;
    $signup = esc_url('https://app.inthecircle.co/signup');
    $download = 'https://apps.apple.com/app/in-the-circle/id' . itc_seo_get_app_store_id();
    ?>
    <div id="itc-sticky-cta" style="display:none;position:fixed;top:0;left:0;right:0;z-index:99999;background:#000;color:#fff;padding:12px 20px;box-shadow:0 2px 10px rgba(0,0,0,0.2);font-family:system-ui,sans-serif;font-size:14px;">
        <div style="max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
            <span style="font-weight:600;">Join InTheCircle – the #1 networking app for creators</span>
            <div style="display:flex;gap:10px;align-items:center;">
                <a href="<?php echo esc_url($signup); ?>" class="itc-sticky-signup" style="background:#fff;color:#000;padding:8px 16px;border-radius:8px;text-decoration:none;font-weight:600;">Sign Up Free</a>
                <a href="<?php echo esc_url($download); ?>" class="itc-sticky-download" style="border:1px solid #fff;color:#fff;padding:8px 16px;border-radius:8px;text-decoration:none;font-weight:600;">Download App</a>
            </div>
        </div>
    </div>
    <script>
    (function(){
        var bar = document.getElementById('itc-sticky-cta');
        if (!bar) return;
        var lastScroll = 0;
        function checkScroll() {
            var y = window.scrollY || document.documentElement.scrollTop;
            if (y > 300) bar.style.display = 'block';
            else bar.style.display = 'none';
            lastScroll = y;
        }
        window.addEventListener('scroll', function(){ requestAnimationFrame(checkScroll); }, { passive: true });
    })();
    </script>
    <?php
}
add_action('wp_footer', 'itc_seo_sticky_cta', 15);
